library(testthat)
library(scdhlm)

test_check("scdhlm")
