# filter data
dat <- subset(dat, {user_filterString})

