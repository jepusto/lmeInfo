
# You're using data that you specified when starting the app.
# You'll need to read it in yourself and store it in an object called 'dat'.

# Clean the variable names 
dat <- janitor::clean_names(dat, case = "parsed").
