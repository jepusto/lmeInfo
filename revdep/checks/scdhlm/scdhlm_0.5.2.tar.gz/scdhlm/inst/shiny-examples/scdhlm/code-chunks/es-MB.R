
# Calculate effect size
res <- with(dat, effect_size_MB(outcome = {user_outcome}, treatment = trt, id = {user_case}, time = {user_session})) 
res
