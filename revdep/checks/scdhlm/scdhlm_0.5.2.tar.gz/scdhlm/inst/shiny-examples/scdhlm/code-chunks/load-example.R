# Load data
data({example_name})
dat <- {example_name}
