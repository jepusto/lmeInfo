# Graph 
graph_SCD(case = {user_case}, phase = {user_phase}, session = {user_session}, outcome = {user_outcome}, design = "{user_design}", data = dat)

